package dowhik;

public class Demodowhile {
	public static void main(String[] args) {
		 int i=10;
		do {
			 System.out.println("number is positive");
			 i++;
	} while (i<15);
}
}