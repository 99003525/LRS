package com.ltts;

import java.util.ArrayList;

public class Employee implements Comparable<Employee> {

	private int Empno;
	private String EmpName;
	private float EmpSalary;
		
	
	public int getEmpno() {
		return Empno;
	}
	public void setEmpno(int empno) {
		Empno = empno;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public float getEmpSalary() {
		return EmpSalary;
	}
	public void setEmpSalary(float empSalary) {
		EmpSalary = empSalary;
	}
}
class Main{
	
	public static void main(String[] args) {
		
		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(Employee(1,"Arya",1112949));
	}
	
}
