
public class DemoWhile {
	public static void main(String[] args) {
		 int i=10;
		 while (i<15) {
			 System.out.println("number is positive");
			 i++;
	}
}
}
