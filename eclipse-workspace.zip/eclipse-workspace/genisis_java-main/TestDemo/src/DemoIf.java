
public class DemoIf {
	public static void main(String[] args) {
		int age=21;
		if(age>=18) {
			System.out.println("Eligible to vote");
		}
	}
}
